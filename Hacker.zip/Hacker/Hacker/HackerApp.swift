//
//  HackerApp.swift
//  Hacker
//
//  Created by Denver Lopes on 5/2/23.
//

import SwiftUI

@main
struct HackerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
